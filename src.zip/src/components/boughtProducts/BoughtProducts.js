

export default function BoughtProducts () {
    return (
        <h2>Hello</h2>
    )
}